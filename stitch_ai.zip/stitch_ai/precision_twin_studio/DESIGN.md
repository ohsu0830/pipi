---
name: Precision Twin Studio
colors:
  surface: '#10131a'
  surface-dim: '#10131a'
  surface-bright: '#363940'
  surface-container-lowest: '#0b0e14'
  surface-container-low: '#191c22'
  surface-container: '#1d2026'
  surface-container-high: '#272a31'
  surface-container-highest: '#32353c'
  on-surface: '#e0e2eb'
  on-surface-variant: '#bac9cc'
  inverse-surface: '#e0e2eb'
  inverse-on-surface: '#2d3037'
  outline: '#849396'
  outline-variant: '#3b494c'
  surface-tint: '#00daf3'
  primary: '#c3f5ff'
  on-primary: '#00363d'
  primary-container: '#00e5ff'
  on-primary-container: '#00626e'
  inverse-primary: '#006875'
  secondary: '#ffb778'
  on-secondary: '#4c2700'
  secondary-container: '#fd9000'
  on-secondary-container: '#613400'
  tertiary: '#f1e9ff'
  on-tertiary: '#370096'
  tertiary-container: '#d6c9ff'
  on-tertiary-container: '#622be5'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#9cf0ff'
  primary-fixed-dim: '#00daf3'
  on-primary-fixed: '#001f24'
  on-primary-fixed-variant: '#004f58'
  secondary-fixed: '#ffdcc1'
  secondary-fixed-dim: '#ffb778'
  on-secondary-fixed: '#2e1500'
  on-secondary-fixed-variant: '#6c3a00'
  tertiary-fixed: '#e8deff'
  tertiary-fixed-dim: '#cdbdff'
  on-tertiary-fixed: '#20005f'
  on-tertiary-fixed-variant: '#4f00d0'
  background: '#10131a'
  on-background: '#e0e2eb'
  surface-variant: '#32353c'
typography:
  display-lg:
    fontFamily: Space Grotesk
    fontSize: 44px
    fontWeight: '700'
    lineHeight: 52px
    letterSpacing: -0.03em
  display-sm:
    fontFamily: Space Grotesk
    fontSize: 32px
    fontWeight: '600'
    lineHeight: 40px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Space Grotesk
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
    letterSpacing: -0.01em
  headline-sm:
    fontFamily: Space Grotesk
    fontSize: 18px
    fontWeight: '600'
    lineHeight: 24px
    letterSpacing: -0.005em
  title-md:
    fontFamily: Inter
    fontSize: 15px
    fontWeight: '600'
    lineHeight: 20px
    letterSpacing: 0em
  body-lg:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
    letterSpacing: 0em
  body-sm:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 16px
    letterSpacing: 0.01em
  telemetry-lg:
    fontFamily: JetBrains Mono
    fontSize: 22px
    fontWeight: '700'
    lineHeight: 26px
    letterSpacing: -0.02em
  telemetry-md:
    fontFamily: JetBrains Mono
    fontSize: 13px
    fontWeight: '500'
    lineHeight: 18px
    letterSpacing: 0em
  telemetry-sm:
    fontFamily: JetBrains Mono
    fontSize: 11px
    fontWeight: '400'
    lineHeight: 14px
    letterSpacing: 0.02em
  label-caps:
    fontFamily: JetBrains Mono
    fontSize: 10px
    fontWeight: '600'
    lineHeight: 12px
    letterSpacing: 0.08em
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  gutter: 0.5rem
  gutter-dense: 0.25rem
  margin: 0.75rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 0.75rem
  space-lg: 1rem
  space-xl: 1.5rem
---

## Brand & Style

This design system serves materials scientists, composite tooling engineers, and aerospace manufacturing operators running real-time autoclave cycles and physics-informed neural network (PINN) surrogates. The aesthetic is rooted in **Precision Technical Brutalism infused with High-Density Instrumental HUD ergonomics**: razor-sharp focus, uncompromising information density, mathematically disciplined alignments, and zero decorative noise.

The interface communicates absolute control, sub-millimeter precision, and mission-critical safety. Rather than feeling like a generic enterprise SaaS dashboard, it mirrors an advanced aerospace mission control or high-end laboratory test console: dark carbonized surfaces, structural micro-grids, hair-thin mechanical dividers, and luminous spectral telemetry markers that directly represent real-world thermal gradients, resin exotherms, and cure kinetics.

## Colors

The palette is engineered around an optical deep-slate/abyssal-navy continuum that minimizes eye fatigue during 12-hour simulation shifts while maximizing spectral contrast for thermal and pressure gradients.

### Color Matrix & Physical Roles
- **Base Canvas (`#080B11`) & Panes (`#0E131F`, `#141B2D`)**: Ultra-deep navy-slate foundation, eliminating pure black to preserve subtle depth and edge delineation between docked tool panes.
- **Active Telemetry & Fluidic Pressure (`#00E5FF` Primary)**: High-luminance cyan reserved for autoclave pressure zones, active viewport tools, selected telemetry states, and interactive focal points.
- **Exotherm & Thermal Dynamics (`#FF9100` Secondary)**: Thermodynamic amber/orange, representing thermocouple readings, ramp-rate heating curves, vitrification thresholds, and exothermic warnings.
- **Physics Surrogate AI (`#7C4DFF` Tertiary)**: Synthetic deep violet reserved exclusively for AI surrogate inferences, PINN confidence intervals, and neural latent space visualizations.
- **Validation & Nominal Equilibrium (`#00E676` Success)**: Laser emerald signifying validated cure windows, thermal runaway safety approvals, and sensor sync integrity.
- **Critical Exotherm Runaway (`#FF1744` Destructive)**: Pure high-voltage crimson reserved strictly for unconstrained cure exotherm alarms and tooling pressure failure.

### Chromatic Surface Guidance
Maintain dark mode as the non-negotiable default. Never use solid accent fills behind large text blocks. Accents are strictly directional: hairline status borders, glowing phosphor node indicators, vector plots, and tabular telemetry readouts.

## Typography

Typography establishes an immediate hierarchy between administrative context, scientific documentation, and instantaneous telemetry.

- **Display & Headings (Space Grotesk)**: Chosen for its engineered, technical geometry. The subtle structural quirks reflect precision engineering blueprints without sacrificing spatial efficiency.
- **Interface & Documentation Body (Inter)**: Provides neutral, fatigue-free reading across dense parameter tables, simulation configuration trees, and layer-stack inspector trees.
- **Kinetic Readouts, Sensors & Syntax (JetBrains Mono)**: Mandatory for all numerical data, thermocouple readings, autoclave barometric pressures, resin glass transition temps ($T_g$), and PINN convergence metrics. Tabular figures prevent layout jumping during continuous multi-hertz simulation streaming.
- **Micro-Labels (`label-caps`)**: All section tags, coordinate axis indicators ($X, Y, Z$), and state tags must be rendered in uppercase monospaced type with positive letter-spacing (`0.08em`) to guarantee instant legibility at small sizes.

## Layout & Spacing

The studio is organized as an **Ultra-Dense Multi-Pane Instrumental Workbench**. Content never flows like a standard document; instead, it snaps strictly to a 4px/8px coordinate sub-grid within fixed docking viewports.

### Architectural Layout Tiers
- **Main Viewport Shell**: Split into three primary docked columns with zero wasted perimeter padding:
  - *Left Drawer (280px - 360px)*: Composite ply schedule, layer laminates, and sensor tree.
  - *Center Core (Flex 1)*: 3D Twin Viewport framed by top instrumental HUD ribbons and bottom simulation timeline scrubbing deck.
  - *Right Rail (320px - 420px)*: Real-time kinetic calculations, PINN surrogate confidence graphs, and AI prescription cards.
- **Grid & Gutters**: Uses `gutter-dense` (4px) between docked tool panels and `gutter` (8px) between major operational viewports. The outer viewport margin is constrained to `0.75rem` to maximize spatial real estate for 3D model interaction.
- **Responsive Adaptations**:
  - *Desktop Workstations (>= 1440px)*: Full 3-column multi-pane studio layout with continuous live-streamed plots.
  - *Field Laptops (1024px - 1439px)*: Right rail collapses into an overlay tab strip; bottom timeline reduces to compact scrubber.
  - *Mobile/Tablet Field Diagnostics (< 1024px)*: Viewport shifts to a single-pane tabbed view prioritizing the 3D twin or sensor telemetry graphs with full-width diagnostic cards.

## Elevation & Depth

Visual depth is produced using **Tonal Layering combined with Low-Contrast Hairline Outlines**, strictly rejecting heavy blurred shadows that bleed into scientific visualizations.

### Structural Depth Architecture
- **Base Canvas Layer (Level 0 - `#080B11`)**: Deepest floor holding passive structural gutters and empty viewport zones.
- **Docked Panes & Toolbars (Level 1 - `#0E131F`)**: Structured panels surrounded by a 1px border of `#1E293B` (or 10% white). No box shadow.
- **Cards, Nodes & Floating Trays (Level 2 - `#141B2D`)**: Interactive tooltips, floating telemetry inspection HUDs, and AI recommendation nodes. Elevated by a crisp 1px perimeter highlight (`rgba(255, 255, 255, 0.08)`) and an ultra-tight ambient occlusion shadow: `0 4px 16px rgba(0, 0, 0, 0.6)`.
- **Active Focus & Modals (Level 3 - `#1A233A`)**: Emergency cure intervention flyouts and modal overrides. Distinct from lower levels via a targeted accent-glow hairline: 1px border of `rgba(0, 229, 255, 0.35)` with a faint directional back-glow `0 0 12px rgba(0, 229, 255, 0.15)`.

### Viewport Superimposition
Floating diagnostic overlays over the 3D canvas must use `backdrop-filter: blur(12px)` with an 80% opacity dark-slate wash (`rgba(14, 19, 31, 0.8)`) to preserve legibility against variable mesh geometries.

## Shapes

The design system enforces a **Chiseled Machined Geometry** (`roundedness: 1`). Large circular radii compromise information density and look out of place in advanced physical modeling tools.

- Standard buttons, input fields, slider tracks, and panel cards adhere to a strict `0.25rem` (4px) corner radius.
- Tooltips, small status chips, and numerical tags use micro-radii of `2px` or sharp `0px` cut corners to evoke industrial lab instruments.
- Viewport frames and modal dialogs maintain `0.5rem` (`rounded-lg`) maximum to provide slight edge distinction against screen hardware borders without softening the professional rigor.
- Status indicators and kinetic plot endpoints remain pure geometric circles or 45-degree rotated telemetry diamonds.

## Components

### Buttons & Trigger Elements
- **Primary Action (Cyan)**: Solid `#00E5FF` fill, `#080B11` bold text (`Space Grotesk` or `Inter`), sharp 4px corners. Hover transitions to bright cyan glow (`box-shadow: 0 0 10px rgba(0, 229, 255, 0.4)`).
- **Secondary / Instrumental**: Transparent slate surface with a 1px border of `#334155`, text in `#E2E8F0`. Hover triggers a 1px border shift to `#00E5FF` and background of `rgba(0, 229, 255, 0.05)`.
- **Destructive Abort**: Crisp dark crimson background (`rgba(255, 23, 68, 0.15)`) with a 1px border of `#FF1744` and text in `#FF1744`.

### 3D Digital Twin Viewport Frame
- Framed in an ultra-thin 1px border (`#1E293B`) with HUD-style corner bracket reticles in `#00E5FF`.
- Overlay axes widget in the bottom-left; floating camera navigation pill (Orthographic, Perspective, Cure Front Heatmap, Void Fraction Analysis) anchored to top-center using translucent slate glass.

### Simulation Timeline Playback Scrubber
- Full-width kinetic bar featuring thermal cycle stages (Heat Ramp 1, Isothermal Dwell, Pressure Hold, Controlled Cool-down).
- Time scrubber head rendered as an illuminated needle (`#00E5FF`) with attached floating timecode readout (`02:41:18.4`).
- Integrated gradient underlay displaying simulated resin degree of cure ($\alpha$) from `0.00` to `1.00`.

### Parametric Slider Cards
- Encapsulated in `#141B2D` panels with an inline monospaced parameter read-out (e.g., `HEAT_RAMP_RATE: 2.5 °C/min`).
- Rail track rendered at 4px thickness in `#1E293B` with accent color fills representing physical domains (Cyan for Barometric Pressure, Amber for Autoclave Temperature).
- Thumb is a vertical chiseled rectangle (6px x 14px) with crisp tactile knurling lines.

### AI Surrogate Recommendation Chips
- Tagged with `#7C4DFF` micro-indicators and labeled `PINN_SURROGATE`.
- Displays real-time delta recommendations (e.g., `"HOLD TEMP +4.2°C TO PREVENT VOID FORMATION"`).
- Features quick-action "Apply to Schedule" button with an inline confidence score metric pill (`99.4% CONF`).

### Telemetry Status Pills & Readouts
- Monospaced typography with a pulsing 6px status bead:
  - Nominal: Green (`#00E676`)
  - Exotherm Imbalance: Amber (`#FF9100`)
  - Runaway Critical: Red (`#FF1744`)
- Key-value pairs organized in high-density grid rows with dotted horizontal leader lines connecting the sensor label to the numerical readout.

### Input Fields & Data Grids
- Inputs have a dark background (`#080B11`), inset 1px border (`#1E293B`), and tabular numeric text entry in `JetBrains Mono`. Focus state snaps instantly to a 1px `#00E5FF` outline with zero transition lag.